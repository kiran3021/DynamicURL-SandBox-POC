import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import UrlCreator from '../components/sandbox/UrlCreator';  // Adjust the path

const query = "";

describe("#offcanvas", () => {
  it("should check whether the input is rendered with the correct value", () => {
    render(<UrlCreator query={query}/>);

    const inputElement = screen.getByDisplayValue("SIMnet Lightyear scaffolding tool");
    expect(inputElement).toBeInTheDocument();
  });
});
